import 'package:flutter/material.dart';
import '../helper_class/api_service_class.dart';
import '../models/requested_customer_model.dart';
import 'customer_profile_details_screen.dart';

class RequestedCustomerScreen extends StatefulWidget {
  const RequestedCustomerScreen({super.key});

  @override
  State<RequestedCustomerScreen> createState() => _RequestedCustomerScreenState();
}

class _RequestedCustomerScreenState extends State<RequestedCustomerScreen> {
  final ApiService _apiService = ApiService();
  List<RequestedCustomerModel> _customers = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchCustomers();
  }

  Future<void> _fetchCustomers() async {
    setState(() => _isLoading = true);
    final customers = await _apiService.getRequestedCustomers();
    if (!mounted) return;
    setState(() {
      _customers = customers;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Requested Customers'),
        backgroundColor: Colors.blue.shade800,
        foregroundColor: Colors.white,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _customers.isEmpty
          ? const Center(child: Text('No requested customers found'))
          : RefreshIndicator(
        onRefresh: _fetchCustomers,
        child: ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: _customers.length,
          itemBuilder: (context, index) {
            final customer = _customers[index];

            final name = customer.yTACustomerName ??
                customer.yTABillToCompanyName ??
                'Unknown Customer';

            final contact = customer.yTABillToCellNo ??
                customer.yTABillToTelephone;

            final email = customer.yTACustomerEmail?.toString();

            final status = _resolveStatus(customer);

            return Card(
              elevation: 2,
              color: Colors.white,
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.blue.shade100,
                  child: const Icon(Icons.person, color: Colors.blue),
                ),
                title: Text(
                  name,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (contact != null && contact.isNotEmpty)
                      Row(
                        children: [
                          const Icon(Icons.phone,
                              size: 16, color: Colors.grey),
                          const SizedBox(width: 4),
                          Expanded(child: Text(contact)),
                        ],
                      ),
                    if (email != null && email.isNotEmpty)
                      Row(
                        children: [
                          const Icon(Icons.email,
                              size: 16, color: Colors.grey),
                          const SizedBox(width: 4),
                          Expanded(child: Text(email)),
                        ],
                      ),
                  ],
                ),
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (status != null)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _statusColor(status).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          status,
                          style: TextStyle(
                            fontSize: 12,
                            color: _statusColor(status),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                  ],
                ),
                onTap: () => _showDetails(customer),
              ),
            );
          },
        ),
      ),
    );
  }

  String? _resolveStatus(RequestedCustomerModel customer) {
    if (customer.isConfirm == true) return 'Confirmed';
    if (customer.isConfirmManagement == true) return 'Mgmt Confirmed';
    if (customer.isConfirm == false) return 'Pending';
    return null;
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'Confirmed':
        return Colors.green.shade800;
      case 'Mgmt Confirmed':
        return Colors.blue.shade800;
      default:
        return Colors.orange.shade800;
    }
  }

  Future<void> _showDetails(RequestedCustomerModel customer) async {
    final isPending =
        customer.isConfirm != true && customer.isConfirmManagement != true;

    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CustomerProfileDetailScreen(
          customerId: customer.yTACustomerId!.toInt(),
          isPending: isPending,
        ),
      ),
    );
  }
}