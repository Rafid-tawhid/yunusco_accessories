import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../helper_class/api_service_class.dart';
import '../models/requested_customer_details_model.dart';

class CustomerProfileDetailScreen extends StatefulWidget {
  final int customerId;
  final bool isPending;

  const CustomerProfileDetailScreen({
    super.key,
    required this.customerId,
    required this.isPending,
  });

  @override
  State<CustomerProfileDetailScreen> createState() =>
      _CustomerProfileDetailScreenState();
}

class _CustomerProfileDetailScreenState
    extends State<CustomerProfileDetailScreen> {
  final ApiService _api = ApiService();

  CustomerProfileDetailModel? _detail;
  bool _loading = true;
  bool _processing = false;
  String? _error;

  static const _primary = Color(0xFF1E3A8A); // deep blue
  static const _primaryLight = Color(0xFF3B82F6);
  static const _accent = Color(0xFF0EA5E9);

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final result = await _api.getCustomerProfileDetails(widget.customerId);

    if (!mounted) return;
    setState(() {
      _detail = result;
      _loading = false;
      _error = result == null ? 'Failed to load customer details' : null;
    });
  }

  Future<void> _handleDecision(bool accept) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(accept ? 'Accept Customer?' : 'Reject Customer?'),
        content: Text(
          accept
              ? 'This customer request will be approved.'
              : 'This customer request will be rejected.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: accept ? Colors.green : Colors.red,
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(accept ? 'Accept' : 'Reject'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    setState(() => _processing = true);
    final ok = await _api.confirmCustomerProfile(widget.customerId, accept ? 1 : 2);
    
    if (!mounted) return;
    setState(() => _processing = false);

    if (ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text(accept ? 'Customer accepted' : 'Customer rejected'),
          backgroundColor: accept ? Colors.green : Colors.red,
        ),
      );
      Navigator.pop(context, accept);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text('Action failed. Please try again.'),
          backgroundColor: Colors.orange,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F4F6),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
          ? _buildError()
          : _buildContent(_detail!),
      bottomNavigationBar: (!_loading && _error == null && widget.isPending)
          ? _buildBottomBar()
          : null,
    );
  }

  Widget _buildError() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.cloud_off, size: 56, color: Colors.grey),
          const SizedBox(height: 12),
          Text(_error!, style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _load,
            icon: const Icon(Icons.refresh),
            label: const Text('Retry'),
          ),
        ],
      ),
    );
  }

  Widget _buildContent(CustomerProfileDetailModel d) {
    final currentAddress = _join([d.billToAddressLine1, d.billToAddressLine2]);
    final factoryLocation = _join([d.shipToAddressLine1, d.shipToAddressLine2]);
    final sisterConcerns = (d.sisterConcern ?? '')
        .split(RegExp(r'[,;]'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();

    final statusLabel = widget.isPending ? 'Pending' : 'Confirmed';
    final statusColor = widget.isPending ? Colors.orange : Colors.green;

    return CustomScrollView(
      slivers: [
        // ---------- GRADIENT HEADER ----------
        SliverAppBar(
          expandedHeight: 200,
          pinned: true,
          elevation: 0,
          backgroundColor: _primary,
          foregroundColor: Colors.white,
          systemOverlayStyle: SystemUiOverlayStyle.light,
          flexibleSpace: FlexibleSpaceBar(
            background: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [_primary, _primaryLight],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 56, 20, 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: statusColor.withOpacity(0.9),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  widget.isPending
                                      ? Icons.hourglass_top
                                      : Icons.verified,
                                  size: 14,
                                  color: Colors.white,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  statusLabel,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Spacer(),
                          if (d.customerCode != null)
                            Text(
                              d.customerCode!,
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        d.customerName ?? d.billToCompanyName ?? 'Unknown',
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        d.billToCompanyName ?? '',
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),

        // ---------- QUICK STATS ----------
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: Row(
              children: [
                _quickStat(
                  icon: Icons.inventory_2_outlined,
                  label: 'Capacity',
                  value: d.totalCapacity != null
                      ? _shortNumber(d.totalCapacity!)
                      : 'N/A',
                ),
                const SizedBox(width: 10),
                _quickStat(
                  icon: Icons.people_outline,
                  label: 'Employees',
                  value: d.totalEmployment?.toString() ?? 'N/A',
                ),
                const SizedBox(width: 10),
                _quickStat(
                  icon: Icons.account_balance_wallet_outlined,
                  label: 'Credit',
                  value: d.creditLimit != null
                      ? _shortNumber(d.creditLimit!)
                      : 'N/A',
                ),
              ],
            ),
          ),
        ),

        // ---------- ADDRESS & CONTACT ----------
        _sectionSliver(
          title: 'Address & Contact',
          icon: Icons.location_on_outlined,
          children: [
            _infoTile(Icons.business_outlined, 'Current Address', currentAddress),
            _infoTile(Icons.factory_outlined, 'Factory Location', factoryLocation),
            _infoTile(Icons.phone_outlined, 'Telephone',
                d.billToTelephone ?? 'N/A'),
            _infoTile(Icons.smartphone_outlined, 'Mobile',
                d.billToCellNo ?? 'N/A'),
            _infoTile(Icons.person_outline, 'Contact Person',
                d.billToContactPerson ?? 'N/A'),
            _infoTile(Icons.email_outlined, 'Email',
                d.customerEmail ?? 'N/A'),
            _infoTile(Icons.calendar_today_outlined, 'Enlisted Date',
                d.createdDate ?? 'N/A'),
          ],
        ),

        // ---------- PRODUCT & CAPACITY ----------
        _sectionSliver(
          title: 'Product & Capacity',
          icon: Icons.category_outlined,
          children: [
            _infoTile(Icons.local_mall_outlined, 'Major Product',
                d.majorProduct ?? 'N/A'),
            _infoTile(Icons.branding_watermark_outlined, 'Major Brands',
                d.majorBrands ?? 'N/A'),
            _infoTile(Icons.scale_outlined, 'Total Capacity',
                d.totalCapacity?.toString() ?? 'N/A'),
            _infoTile(Icons.badge_outlined, 'Total Employment',
                d.totalEmployment?.toString() ?? 'N/A'),
          ],
        ),

        // ---------- DEPARTMENT PERSONNEL ----------
        _sectionSliver(
          title: 'Department Personnel',
          icon: Icons.groups_outlined,
          children: [
            _infoTile(Icons.account_balance_outlined, 'Board of Directors',
                d.boardOfDirectors ?? 'N/A'),
            _infoTile(Icons.storefront_outlined, 'Merchandise',
                d.merchandiseDepartment ?? 'N/A'),
            _infoTile(Icons.handshake_outlined, 'Commercial',
                d.commercialDepartment ?? 'N/A'),
            _infoTile(Icons.receipt_long_outlined, 'Accounts',
                d.accountsDepartment ?? 'N/A'),
          ],
        ),

        // ---------- SISTER CONCERNS ----------
        if (sisterConcerns.isNotEmpty)
          _sectionSliver(
            title: 'Sister Concerns',
            icon: Icons.apartment_outlined,
            children: [
              for (int i = 0; i < sisterConcerns.length; i++)
                _numberedTile(i + 1, sisterConcerns[i]),
            ],
          ),

        // ---------- BANK & PAYMENT ----------
        _sectionSliver(
          title: 'Bank & Payment',
          icon: Icons.account_balance_outlined,
          children: [
            _infoTile(Icons.credit_card_outlined, 'Bank Account',
                d.bankAccount ?? 'N/A'),
            _infoTile(Icons.payments_outlined, 'Payment Mode',
                d.paymentMode ?? 'N/A'),
          ],
        ),

        // ---------- APPROVAL INFO ----------
        _sectionSliver(
          title: 'Approval Info',
          icon: Icons.verified_user_outlined,
          children: [
            _infoTile(Icons.person_pin_outlined, 'Approved By',
                d.approvedBy?.toString() ?? 'N/A'),
            _infoTile(Icons.event_available_outlined, 'Approved Date',
                d.approvedDate ?? 'N/A'),
            _infoTile(Icons.event_busy_outlined, 'Rejected Date',
                d.rejectedDate ?? 'N/A'),
            _infoTile(Icons.rule_outlined, 'CP Confirmed Date',
                d.cpConfirmedDate ?? 'N/A'),
            _infoTile(Icons.savings_outlined, 'Max Discount',
                d.maxDiscountAmount?.toString() ?? 'N/A'),
            _infoTile(Icons.percent_outlined, 'Discount %',
                d.discountPercentage?.toString() ?? 'N/A'),
          ],
        ),

        // ---------- REMARKS ----------
        _sectionSliver(
          title: 'Remarks & History',
          icon: Icons.notes_outlined,
          children: [
            _remarkBlock('Client History', d.clientHistory),
            _remarkBlock('Management Remarks', d.managementRemarks),
          ],
        ),

        const SliverToBoxAdapter(child: SizedBox(height: 100)),
      ],
    );
  }

  Widget _buildBottomBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 12,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _processing ? null : () => _handleDecision(false),
                icon: const Icon(Icons.close_rounded),
                label: const Text('Reject'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.red.shade600,
                  side: BorderSide(color: Colors.red.shade300),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              flex: 2,
              child: ElevatedButton.icon(
                onPressed: _processing ? null : () => _handleDecision(true),
                icon: _processing
                    ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
                    : const Icon(Icons.check_rounded),
                label: Text(_processing ? 'Processing…' : 'Accept'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF16A34A),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------- SLIVERS / TILES ----------

  Widget _sectionSliver({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: _primary.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, size: 16, color: _primary),
                ),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF111827),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 10,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(children: children),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoTile(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: Colors.grey.shade500),
          const SizedBox(width: 12),
          SizedBox(
            width: 100,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey.shade600,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 13.5,
                color: Color(0xFF111827),
                fontWeight: FontWeight.w600,
                height: 1.35,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _numberedTile(int index, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 22,
            height: 22,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: _accent.withOpacity(0.12),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              '$index',
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: _accent,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 13.5,
                color: Color(0xFF111827),
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _remarkBlock(String label, String? value) {
    final text = (value == null || value.isEmpty) ? 'N/A' : value;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.sticky_note_2_outlined,
                  size: 16, color: Colors.grey.shade500),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey.shade600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFF9FAFB),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0xFFE5E7EB)),
            ),
            child: Text(
              text,
              style: const TextStyle(
                fontSize: 13,
                height: 1.5,
                color: Color(0xFF374151),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _quickStat({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            Icon(icon, size: 20, color: _primary),
            const SizedBox(height: 6),
            Text(
              value,
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Color(0xFF111827),
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
            ),
          ],
        ),
      ),
    );
  }

  String _join(List<String?> parts) {
    final s = parts.whereType<String>().where((e) => e.isNotEmpty).join(', ');
    return s.isEmpty ? 'N/A' : s;
  }

  String _shortNumber(num n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return n.toString();
  }
}